package ants.frozenants;

import ants.util.*;

public class Target {
	
	private Tile location;
	private Aim direction;
	private TargetType targettype;
	
	public enum TargetType {
		FOOD, MY_ANT, ENEMY_ANT
	};
	
	
	public Target(Tile tile, Aim aim, TargetType targettype) {
		location = tile;
		direction = aim;
		this.targettype = targettype;
	}
}
