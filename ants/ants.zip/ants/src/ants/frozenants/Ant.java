package ants.frozenants;

import java.util.List;

import ants.util.*;

public class Ant {
	private Tile location;
	private List<Target> targets; 

}
